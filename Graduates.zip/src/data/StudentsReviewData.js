export const reviews = [
  "Review 1: This course was amazing!",
  "Review 2: I learned so much and the instructors were great!",
  "Review 3: Highly recommend this to anyone wanting to learn.",
  "Review 4: Great content and very detailed explanations.",
  "Review 5: This was a game-changer for my career."
];