export const NavData = [
  {
    heading: "الرئيسية",
    link: "home",
  },
  {
    heading: "الاقسام",
    link: "sections",
  },
  {
    heading: "الدورات",
    link: "courses",
  },
  {
    heading: "لمحة عامة",
    link: "overview",
  },
  {
    heading: "الدكاترة",
    link: "coaches",
  },
];
